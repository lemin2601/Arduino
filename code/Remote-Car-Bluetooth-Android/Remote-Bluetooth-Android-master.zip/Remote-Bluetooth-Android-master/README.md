Java and Android Bluetooth
=====================

This project makes your Android phone as a remote for your computer by connecting via Bluetooth

##Usage

Run the RemoteBluetoothServer project in your PC and install the RemoteBluetooth app in your Android phone.

##Notes

If you have to run the server in linux, then make sure you install the libbluetooth-dev package.

If you have to run the server in mac, configure eclipse to pass the -d32 JVM argument.

##Contact
[@luugiathuy](http://twitter.com/luugiathuy)
