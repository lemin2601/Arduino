#ifndef __MEAT__
#define __MEAT__
#include "Object.h"
class Meat: public Object {
private:
  static word pointPerMeat;
public:
  Meat(byte posX, byte posY);
  Meat(Pos pos);
  virtual void render();
  virtual void move(byte direction);
  virtual int getType();

  virtual word point();

  static void setPointPerMeat(const word point) {
    pointPerMeat = point;
  }
};

#endif
