#include<Arduino.h>
#include "ID.h"
void ID::initialize() {
  counter = 0;
}

word ID::getId() {
  return counter++;
}
