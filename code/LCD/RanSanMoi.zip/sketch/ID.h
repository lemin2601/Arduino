#ifndef __ID__
#define __ID__
class ID {
private:
  word counter;
public:
  void initialize();
  static ID* getInstance() {
    static ID* instance = new ID;
    return instance;  
  }

  word getId();
};

#endif
