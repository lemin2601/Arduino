#include<Arduino.h>
#include "config.h"
const bool operator==(const Pos a, const Pos b) {
  return a.x == b.x && a.y == b.y;
}

const bool operator!=(const Pos a, const Pos b) {
  return a.x != b.x || a.y != b.y;
}
