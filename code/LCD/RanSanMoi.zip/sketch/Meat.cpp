#include<Arduino.h>
#include "Meat.h"
#include "Display.h"
word Meat::pointPerMeat = 1;

Meat::Meat(byte posX, byte posY): Object(MEAT_DEFAULT_BMP, BMP_WIDTH, BMP_HEIGHT) {
  setPosition(posX, posY);
}
Meat::Meat(Pos pos): Object(MEAT_DEFAULT_BMP, BMP_WIDTH, BMP_HEIGHT) {
  setPosition(pos.x, pos.y);
}
void Meat::render() {
  Display::getInstance()->drawBitmap(getX(), getY(), getBitmap(), getRenderWidth(), getRenderHeight(), BLACK);
}
void Meat::move(byte direction) {//do nothing, it can't move
  return;
}
int Meat::getType() {
  return MEAT_TYPE;
}

word Meat::point() {
  return pointPerMeat;
}
