#include<Arduino.h>
#include "GameController.h"
void GameController::addPoint(word point) {
  m_point += point;
}

GameController::GameController(): m_point(B0) {
  m_snake = new Snake(3, BMP_WIDTH, BMP_HEIGHT);
  m_direction = DIRECTION_BEFORE_MOVE;
  m_meat.setMax(MEAT_COUNT);
  for (byte i = 0; i < MEAT_COUNT; i++)
    m_meat.push_front(new Meat(generateMeatPosition()));

  Display::getInstance()->setTextSize(1);
  Display::getInstance()->setTextColor(BLACK);

  m_status = STATUS_RUNNING;
}

const bool GameController::isRunning() const {
  return m_status == STATUS_RUNNING;
}

const bool GameController::isGameOver() const {
  return m_status == STATUS_GAME_OVER;
}

//get snake
Snake *GameController::getSnake() {
  return m_snake;
}

//set direction
void GameController::setDirection(byte direction) {
  m_direction = direction;
}

//generate Meat
Pos GameController::generateMeatPosition() {
  bool ok = false;
  byte  randWidth = Display::getInstance()->width() / BMP_WIDTH,
        randHeight= Display::getInstance()->height() / BMP_HEIGHT;
  Pos pos;
  do {
    ok = false;
    byte x = rand() % randWidth;
    byte y = rand() % randHeight;
    x *= BMP_WIDTH;
    y *= BMP_HEIGHT;
    pos.x = x;
    pos.y = y;
    
    for (byte i = 0; i < m_meat.size(); i++) {
      if (m_meat.at(i)->getPos() == pos) {
        if (__DEBUG__) {
          Serial.print(pos.x);
          Serial.print(F(" "));
          Serial.println(pos.y);
          Serial.print(m_meat.at(i)->getX());
          Serial.print(F(" "));
          Serial.println(m_meat.at(i)->getY());
        }
        ok = true;
        break;
      }
    }
    if (!ok)
      ok = m_snake->isOnSnake(pos);
  } while (ok);
  if (__DEBUG__) {
    Serial.println(F("Meat at pos: "));
    Serial.print(pos.x);
    Serial.print(F(" "));
    Serial.println(pos.y);
  }
  return pos;
}
//render game over
void GameController::renderGameOver() {
  static byte state = 0;
  Display::getInstance()->clearDisplay();
  Display::getInstance()->setCursor(0, ((state > 50) ? 0 : 20));
  Display::getInstance()->print(((state > 50) ? F("Do con ga") : F("Thua roi haha!")));
  Display::getInstance()->display();
  state = (state + 1) % 100;
}

//render
void GameController::render() {
  if (isGameOver())
    return renderGameOver();
  Display::getInstance()->clearDisplay();
  m_snake->render();
  for (byte i = 0; i < m_meat.size(); i++)
    m_meat.at(i)->render();
  
  Display::getInstance()->setCursor(0,0);
  Display::getInstance()->print(getPoint());
  Display::getInstance()->display();
  
}


//get direction
byte GameController::getDirection() const {
  return m_direction;
}

//move
void GameController::move () {
  if (isGameOver())
    return;
  m_snake->move(getDirection());
  setDirection(DIRECTION_BEFORE_MOVE);
  Pos snakeHeadPos = m_snake->getHeadPosition();

  //eat meat
  for (int i = 0; i < m_meat.size(); i++) {
    if (snakeHeadPos == m_meat.at(i)->getPos()) {
      addPoint(m_meat.at(i)->point());
      m_meat.at(i)->setPosition(generateMeatPosition());
      m_snake->addComponent();
      break;
    }
  }

  //eat yourself
  if (m_snake->isOnSnake(snakeHeadPos, 1))
    m_status = STATUS_GAME_OVER;
 
}

//get Point
unsigned long GameController::getPoint() const {
  return m_point;
}
