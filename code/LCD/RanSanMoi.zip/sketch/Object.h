#ifndef __OBJECT__
#define __OBJECT__
#include "config.h"
#include "ID.h"
class Object {
private:
  const unsigned char* PROGMEM m_bitmap;
  byte m_width;
  byte m_height;
  byte m_renderWidth;
  byte m_renderHeight;
  word m_id;
  Pos m_pos;
protected:
  //set render width
  virtual void setRenderWidth();

  //set render height
  virtual void setRenderHeight();

  //set render size
  virtual void setRenderSize();

  //get width
  virtual byte getWidth() const;

  //get height
  virtual byte getHeight() const;

  //get bitmap
  virtual const unsigned char* getBitmap();

  //get renderWidth
  virtual byte getRenderWidth() const;

  //get renderHeight
  virtual byte getRenderHeight() const;
  
  //get id
  virtual word getId() const;
public:
  Object(const unsigned char *bitmap, byte width, byte height);

   //get x
  virtual byte getX() const;

  //get y
  virtual byte getY() const;

  //set object's position
  virtual void setPosition(Pos pos);

  //set position
  virtual void setPosition(const byte x, const byte y);

  //get Pos
  virtual Pos getPos() const;

  //check object is on the other
  const bool isOnObject(Object *obj);
  
  virtual void render() = 0;
  virtual void move(byte direction) = 0;
  virtual int getType() = 0;
};

#endif
