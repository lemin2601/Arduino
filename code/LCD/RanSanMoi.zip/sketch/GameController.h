#ifndef __GAME_CONTROLLER__
#define __GAME_CONTROLLER__
#include "Snake.h"
#include "Display.h"
#include "Meat.h"
class GameController {
private:
  Snake *m_snake;
  Deque<Meat*> m_meat;
  unsigned long m_point;
  byte m_direction;
  byte m_status;
protected:
  void addPoint(word point);
public:
  GameController();

  const bool isRunning() const;

  const bool isGameOver() const;

  //get snake
  Snake *getSnake();

  //set direction
  void setDirection(byte direction);

  //generate Meat
  Pos generateMeatPosition();
  //render game over
  void renderGameOver();
  
  //render
  void render();
  

  //get direction
  byte getDirection() const;

  //move
  void move ();

  //get Point
  unsigned long getPoint() const;
};
#endif
