#ifndef __DISPLAY__
#define __DISPLAY__
#include <Adafruit_GFX.h>
#include <Adafruit_PCD8544.h>

class Display: public Adafruit_PCD8544 {
public:
  static Adafruit_PCD8544* getInstance() {
    static Adafruit_PCD8544 * instance = new Adafruit_PCD8544(LCD_SCLK_PIN, LCD_DIN_PIN, LCD_DC_PIN, LCD_CS_PIN, LCD_RST_PIN);
    return instance;
  }
};
#endif
