#include<Arduino.h>
#include "Snake.h"
Snake::Snake() {}
Snake::Snake(int length, const byte x, const byte y) {
  //set max snake length
  m_snake.setMax(MAX_SNAKE_LENGTH);
  ID::getInstance()->initialize();
  if (length < 3)
    length = 3;
  m_snake.push_back(new SnakeComponent(SNAKE_HEAD_BMP, BMP_WIDTH, BMP_HEIGHT));  //head
  for (byte i = 1; i < length; i++)
    m_snake.push_back(new SnakeComponent(SNAKE_BODY_BMP, BMP_WIDTH, BMP_HEIGHT));//body

  //set position
  for (byte i = 0; i < length; i++) {
    m_snake.at(i)->setPosition(x, y + i * BMP_WIDTH);
  }

  //set default direction
  for (byte i = 0; i < length; i++)
    m_direction.push_back(DIRECTION_UP);

  m_direction.setMax(length);
}

//check pos is con snake
bool Snake::isOnSnake(const Pos pos, bool expectHead) {
  for (byte i = (expectHead) ? 1 : 0; i < m_snake.size(); i++) {
    if (m_snake.at(i)->getPos() == pos)
      return true;
  }
  return false;
}

//move
void Snake::move(byte direction) {
  if (direction == DIRECTION_BEFORE_MOVE)
    m_direction.push_front(m_direction.front());
  else {
    byte oldDirection = m_direction.front() + byte(2);
    oldDirection %= byte(4);
    if (oldDirection != direction)
      m_direction.push_front(direction);
    else 
      m_direction.push_front(m_direction.front());
  }
  for (int i = 0; i < m_snake.size(); i++) {
    m_snake.at(i)->move(m_direction.at(i));
  }
}


//render all snake component
void Snake::render() {
  for (int i = 0; i < m_snake.size(); i++) {
    m_snake.at(i)->render();
  }
}

//get Head position
Pos Snake::getHeadPosition() {
  return m_snake.front()->getPos();
}


//add body after body
void Snake::addComponent() {
  if (m_snake.size() < m_snake.getMax()) {
    byte oldDirection = m_direction.back();
    m_direction.setMax(m_direction.getMax() + 1);
    Pos oldPos = m_snake.back()->getPos();
    m_snake.push_back(new SnakeComponent(SNAKE_BODY_BMP, BMP_WIDTH, BMP_HEIGHT));
    ((SnakeComponent *)m_snake.back())->setPosAfter(oldPos, oldDirection);
  }
}
