#include<Arduino.h>
#include "Object.h"
//set render width
void Object::setRenderWidth() {
  m_renderWidth = 0;
  while (m_renderWidth < m_width)
    m_renderWidth += 8;
}

//set render height
void Object::setRenderHeight() {
  m_renderHeight = 0;
  while (m_renderHeight < m_height)
    m_renderHeight += 8;
}

//set render size
void Object::setRenderSize() {
  setRenderWidth();
  setRenderHeight();
}

//get width
byte Object::getWidth() const {
  return m_width;
}

//get height
byte Object::getHeight() const {
  return m_height;
}

//get bitmap
const unsigned char* Object::getBitmap() {
  return m_bitmap;
}

byte Object::getRenderWidth() const {
  return m_renderWidth;
}

//get renderHeight
byte Object::getRenderHeight() const {
  return m_renderHeight;
}

//get id
word Object::getId() const {
  return m_id;
}

Object::Object(const unsigned char *bitmap, byte width, byte height): m_width(width), m_height(height) {
  m_bitmap = bitmap;
  m_id = ID::getInstance()->getId();
  setRenderSize();
};

 //get x
byte Object::getX() const {
  return m_pos.x;
}

//get y
byte Object::getY() const {
  return m_pos.y;
}

//set object's position
void Object::setPosition(Pos pos) {
  m_pos = pos;
}

//set position
void Object::setPosition(const byte x, const byte y) {
  Pos pos = {x, y};
  setPosition(pos);
}

//get Pos
Pos Object::getPos() const {
  return m_pos;
}

//check object is on the other
const bool Object::isOnObject(Object *obj) {
  return (m_pos == obj->getPos());
}
