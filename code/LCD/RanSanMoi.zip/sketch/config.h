#ifndef __CONFIG__
#define __CONFIG__
//debug
#define __DEBUG__             0

//max snake length
#define MAX_SNAKE_LENGTH      20

//button PIN
#define BUTTON_UP     10
#define BUTTON_DOWN   11
#define BUTTON_LEFT   12
#define BUTTON_RIGHT  13

//LCD pin
#define LCD_SCLK_PIN  7
#define LCD_DIN_PIN 6
#define LCD_DC_PIN  5
#define LCD_CS_PIN  4
#define LCD_RST_PIN 3

//Workscheduler cycle time
#define WORKSCHEDULER_RENDER_CYCLE_TIME     20UL
#define WORKSCHEDULER_READ_BUTTONCYCLE_TIME 10UL
#define WORKSCHEDULER_PRINT_TIME_CYCLE_TIME 1500UL
#define WORKSCHEDULER_PRINT_POINT_CYCLE_TIME 1500UL

//Analog config
#define ANALOG_PIN    A0
#define ANALOG_MIN    720
#define ANALOG_MAX    1023

//point and speed
#define MAX_POINT_PER_MEAT  10
#define MIN_POINT_PER_MEAT  1
#define MOVE_MAX_SPEED      20
#define MOVE_MIN_SPEED      300


//direction
#define DIRECTION_UP          0
#define DIRECTION_LEFT        1
#define DIRECTION_DOWN        2
#define DIRECTION_RIGHT       3
#define DIRECTION_BEFORE_MOVE 4

//MEAT
#define MEAT_COUNT    2


//bitmap size
#define BMP_WIDTH   5
#define BMP_HEIGHT  5

#define BLOCK_TYPE            0
#define SNAKE_COMPONENT_TYPE  1
#define ROCK_TYPE             2
#define MEAT_TYPE             3

//status
#define STATUS_RUNNING        4
#define STATUS_GAME_OVER      1

//struct Pos
struct Pos {
  byte x;
  byte y;
};

const bool operator==(const Pos a, const Pos b);

const bool operator!=(const Pos a, const Pos b);

const char VX[] = {0, 1, 0, -1};
const char VY[] = {-1, 0, 1, 0};

//object bitmap
static const unsigned char PROGMEM SNAKE_HEAD_BMP[] = {B00100000, B01010000, B10001000, B11011000, B11111000, 0, 0, 0};
static const unsigned char PROGMEM SNAKE_BODY_BMP[] = {B11111000, B11111000, B11111000, B11111000, B11111000, 0, 0, 0};
static const unsigned char PROGMEM MEAT_DEFAULT_BMP[] = {0b01000000, 0b10101000, 0b10111000, 0b11111000, 0b01110000, 0, 0, 0};

#endif
