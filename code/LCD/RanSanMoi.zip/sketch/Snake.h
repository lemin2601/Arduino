#ifndef __SNAKE__
#define __SNAKE__
#include "SnakeComponent.h"
#include "deque.h"


class Snake {
private:
  Deque<Object *> m_snake;
  Deque<byte>     m_direction;
protected:
  
public:
  Snake();
  Snake(int length, const byte x, const byte y);

  //check pos is con snake
  bool isOnSnake(const Pos pos, bool expectHead = false);

  //move
  void move(byte direction);


  //render all snake component
  void render();

  //get Head position
  Pos getHeadPosition();


  //add body after body
  void addComponent();
};

#endif
