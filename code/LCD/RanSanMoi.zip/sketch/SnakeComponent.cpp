#include<Arduino.h>
#include "SnakeComponent.h"
SnakeComponent::SnakeComponent(const unsigned char *bitmap, byte width, byte height): Object(bitmap, width, height) {
  m_borderPositionWidth = Display::getInstance()->width()- getWidth() - (Display::getInstance()->width() % getWidth());
  m_borderPositionHeight = Display::getInstance()->height() - getHeight() - (Display::getInstance()->height() % getHeight());
}

void SnakeComponent::formatPos(Pos &pos, byte direction) {
  pos.x += VX[direction] * getWidth();
  pos.y += VY[direction] * getHeight();
  
  if (pos.x > m_borderPositionWidth)   //out of display range
    if (direction == DIRECTION_RIGHT)
      pos.x = m_borderPositionWidth;
    else if (direction == DIRECTION_LEFT)
      pos.x = 0;
  if (pos.y > m_borderPositionHeight)
    if (direction == DIRECTION_UP)
      pos.y = m_borderPositionHeight;
    else if (direction == DIRECTION_DOWN)
      pos.y = 0;
}

void SnakeComponent::move(byte direction) {
  if (__DEBUG__) {
    Serial.print(getId());
    Serial.print(F(" move "));
    Serial.print(direction);
  }
  Pos pos = getPos();
  formatPos(pos, direction);
  setPosition(pos);
  if (__DEBUG__) {
    Serial.print(F(" "));
    Serial.print(pos.x);
    Serial.print(F(" "));
    Serial.println(pos.y);
  }
}
void SnakeComponent::setPosAfter(Pos oldPos, byte oldDirection) {
  byte direction = (oldDirection + 2) % 4;
  formatPos(oldPos, direction);
  setPosition(oldPos);
}

void SnakeComponent::render() {
  Display::getInstance()->drawBitmap(getX(), getY(), getBitmap(), getRenderWidth(), getRenderHeight(), BLACK);
}

int SnakeComponent::getType() {
  return SNAKE_COMPONENT_TYPE;
}
