#ifndef __SNAKE_COMPONENT__
#define __SNAKE_COMPONENT__
#include "Object.h"
#include "Display.h"


class SnakeComponent: public Object {
private:
  word m_borderPositionWidth;
  word m_borderPositionHeight;
public:
  SnakeComponent(const unsigned char *bitmap, byte width, byte height);

  void formatPos(Pos &pos, byte direction);
  
  virtual void move(byte direction);

  virtual void setPosAfter(Pos oldPos, byte oldDirection);

  virtual void render();

  virtual int getType();
};

#endif
