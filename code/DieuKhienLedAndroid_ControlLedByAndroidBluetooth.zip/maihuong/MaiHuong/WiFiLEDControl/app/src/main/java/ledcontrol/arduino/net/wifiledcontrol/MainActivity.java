package ledcontrol.arduino.net.wifiledcontrol;

import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

/*
    Dev by Thanh Tran 2016
 */

public class MainActivity extends AppCompatActivity {
    //UI Elements
    Button btnLED1, btnLED2, btnLED3, btnLED4;
    EditText txtAddressAndPort;

    Socket myAppSocket = null;
    public static String wifiModuleIP = "";
    public static int wifiModulePort = 0;
    public static String LEDID = "0";
    public static boolean isOnLed[] = new boolean[4];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLED1 = (Button) findViewById(R.id.btnLED1);
        btnLED2 = (Button) findViewById(R.id.btnLED2);
        btnLED3 = (Button) findViewById(R.id.btnLED3);
        btnLED4 = (Button) findViewById(R.id.btnLED4);

        txtAddressAndPort = (EditText) findViewById(R.id.txtAddress);

        btnLED1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getIPandPort();
                if(isOnLed[0]){
                    LEDID = "6";
                    btnLED1.setBackgroundColor(Color.RED);
                }else{
                    LEDID = "1";
                    btnLED1.setBackgroundColor(Color.GREEN);
                }
                isOnLed[0] = !isOnLed[0];
                Socket_AsyncTask turnLED1 = new Socket_AsyncTask();
                turnLED1.execute();
            }
        });

        btnLED2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getIPandPort();
                if(isOnLed[1]){
                    LEDID = "7";
                    btnLED2.setBackgroundColor(Color.RED);
                }else{
                    LEDID = "2";
                    btnLED2.setBackgroundColor(Color.GREEN);
                }
                isOnLed[1] = !isOnLed[1];
                Socket_AsyncTask turnLED2 = new Socket_AsyncTask();
                turnLED2.execute();
            }
        });

        btnLED3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getIPandPort();
                if(isOnLed[2]){
                    LEDID = "8";
                    btnLED3.setBackgroundColor(Color.RED);
                }else{
                    LEDID = "3";
                    btnLED3.setBackgroundColor(Color.GREEN);
                }
                isOnLed[2] = !isOnLed[2];
                Socket_AsyncTask turnLED3 = new Socket_AsyncTask();
                turnLED3.execute();
            }
        });

        btnLED4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getIPandPort();
                if(isOnLed[3]){
                    LEDID = "9";
                    btnLED4.setBackgroundColor(Color.RED);
                }else{
                    LEDID = "4";
                    btnLED4.setBackgroundColor(Color.GREEN);
                }
                isOnLed[3] = !isOnLed[3];
                Socket_AsyncTask turnLED4 = new Socket_AsyncTask();
                turnLED4.execute();
            }
        });
    }

    //helper functions
    private void getIPandPort()
    {
        String iPAndPort = txtAddressAndPort.getText().toString();
        Log.d("MYTEST", "IP String:" + iPAndPort);
        String tmp[] = iPAndPort.split(":");
        wifiModuleIP = tmp[0];
        wifiModulePort = Integer.valueOf(tmp[1]);

        Log.d("MYTEST", "IP:" + wifiModuleIP);
        Log.d("MYTEST", "Port:" + wifiModulePort);
    }

    //helper class
    public class Socket_AsyncTask extends AsyncTask<Void, Void, Void>
    {
        Socket socket;

        @Override
        protected Void doInBackground(Void... params) {
            try {
                InetAddress inetAddress = InetAddress.getByName(MainActivity.wifiModuleIP);
                socket = new java.net.Socket(inetAddress, MainActivity.wifiModulePort);
                DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
                //dataOutputStream.writeChar(MainActivity.LEDID);
                dataOutputStream.writeBytes(LEDID);
                dataOutputStream.close();
                socket.close();
            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
