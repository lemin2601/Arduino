Requires TinyGPS++ and Adafruit SSD1306 libraries.
