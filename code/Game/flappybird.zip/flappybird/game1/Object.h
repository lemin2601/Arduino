class Object
{
  protected:
  unsigned char* PROGMEM image;
  int position_x;
  int position_y;
  int speed_x;
  int speed_y;
  int width;
  int heigh;
  public:
  void drawImage()
  {
    display.drawBitmap(position_x,position_y,image,width,heigh,BLACK);
  }
  virtual void Update();
  
  void SetPositiony(int y)
  {
    position_y=y;
  }
  bool vaCham(Object &t)
  {
    if((position_x+width>t.position_x)&&(position_x<t.position_x+t.width)
         &&(position_y+heigh>t.position_y)&&(position_y<t.position_y+t.heigh))
         return true;
    else return false;
  }
  
  int GetPositionx()
  {
    return position_x;
  }
  int GetPositiony()
  {
    return position_y;
  }
  void SetPositionx(int x)
  {
    position_x=x;
  }
  
};

